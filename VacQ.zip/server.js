const express = require("express");
const dotenv = require("dotenv");
const hospitals = require("./routes/hospitals");
//Load env vars
dotenv.config({ path: "./config/config.env" });

const app = express();

app.get("/", (req, res) => {
  // 1. res.send('<h1>Hello from Express</h1>');
  // 2. res.send({name: 'John', age: 30});
  // 3. res.json({name: 'John', age: 30});
  // 4. res.status(400).json({success:false});
  // 5. res.status(400)
  res.status(200).json({ success: true, data: { id: 1 } });
});

app.use("/api/v1/hospitals", hospitals);

const PORT = process.env.PORT || 5001;
app.listen(
  PORT,
  console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`)
);
